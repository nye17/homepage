#!/usr/bin/perl

#@Description:

#@Author:
#Ying Zu
#
#@ChangeLog:

# various formats
$format8 = " %16.6f %16.6f %8d %16.6f %16.6f %16.6f %16.6f %16.6f\n";

$execute = 'spear';

$numArgs = $#ARGV + 1;

# take the twrange from command-line or set to default value
if($numArgs ne 8) {
    die "USAGE:  lagwidgrid.pl inputfile outputfile lagmin lagmax lagstep widmin widmax widstep \n";
}else{
     $input = $ARGV[0];
    $output = $ARGV[1];
    $lagmin = $ARGV[2];
    $lagmax = $ARGV[3];
    $lagstp = $ARGV[4];
    $widmin = $ARGV[5];
    $widmax = $ARGV[6];
    $widstp = $ARGV[7];
    if(-e $output) {
        die "you retard, don't override $output\n";
    }
    $nl   = int(($lagmax-$lagmin)/$lagstp)+1;
    print "setting lag range to $lagmin $lagmax $nl\n";
    $nw   = int(($widmax-$widmin)/$widstp)+1;
    print "setting width range to $widmin $widmax $nw\n";
}

if(! -e $input) {die "NO $input exist!\n";}

open(INFILE,"<$input");
#well, here is the lc_object_line.dat
$file = <INFILE>;

# read the 1st line of INFILE to get ncurve
$ncurve = qx(head -n 1 $file);
chomp $ncurve;
if($ncurve != 2) {die "too many light curves in tophat mode, wrong input file?\n";}
$mode = <INFILE>; 
$para = <INFILE>; 
@entries = split ' ',$para;
$sigma0= $entries[0];
$tau0  = $entries[1];
$scale0= $entries[3];
close(INFILE);
print "sigma: $sigma0 tau: $tau0 scale: $scale0\n";

# open dat file for output
open(RESULTS,">$output");

for ($i=0; $i<$nl; $i++) {
     $lag  = $lagmin + $i*$lagstp;    
    for ($j=0; $j<$nw; $j++) {
        $wid = $widmin + $j*$widstp;    
            open(OTFILE,">lwinput.tophat");
            printf OTFILE "$file";
            printf OTFILE "$mode";
            printf OTFILE "$sigma0 $tau0 $lag $scale0 $wid\n";
            printf OTFILE "1  1 0  1 0\n";
# no prediction
            printf OTFILE "0\n";
# no mcmc (otherwise why the heck this routine exists!)
            printf OTFILE "0\n";
            close(OTFILE);
            if (-e $execute) {
                system("$execute < lwinput.tophat");
            } else {
                die "No $execute found!\n";
            }

            open(INFILE,"<best3.new");
            $modeline  = <INFILE>;
            $paramline = <INFILE>;  
            $likeline  = <INFILE>;  @entries = split ' ',$likeline ; $like = $entries[0];
            $chiline   = <INFILE>;  @entries = split ' ',$chiline  ; $chi  = $entries[0]; $dof = $entries[1];
            $params    = <INFILE>;  @entries = split ' ',$params   ; $sigma  = $entries[0]; $tau = $entries[1]; $scale = $entries[3];
            printf RESULTS $format8,$like,$chi,$dof,$lag,$wid,$sigma,$tau,$scale;
            close(INFILE);
    }
}

close(RESULTS);
