#!/usr/bin/perl

#@Description:
#find prior of sigma and tau for given mcmc file
#it could be generic -- find prior for any parameters, by changing colid1/2, or to assign output filename, by changing statfile.
#
#@Author:
#Ying Zu
#
#@Changelog:

sub bynumber { $a <=> $b }

$numArgs = $#ARGV + 1;
if ($numArgs ne 1){
    die "USAGE: get_stprior.pl mcmcfile\n";
}

$mcmcfile = $ARGV[0];

#could be more generic by specifying in the command line
$statfile = 'stats.dat';
$colid1   = 5;
$colid2   = 4;

open INFILE,"<$mcmcfile";

$npt  = 0;
$entid1   = $colid1 - 1;
$entid2   = $colid2 - 1;

while(<INFILE>) {
  $line         = $_;
  @entries      = split ' ',$line;
  if($entid1 >= 0){$item1[$npt] = $entries[$entid1]};
  if($entid2 >= 0){$item2[$npt] = $entries[$entid2]};
  $npt++;
}
close(INFILE);

$nmed    = $npt/2;
$nlow    = 0.158*$npt;
$nhig    = (1-0.158)*$npt;

if($entid1 >= 0){
    @sortitem1= sort bynumber @item1;
    $meditem1= $sortitem1[$nmed];
    $lowitem1= $sortitem1[$nlow];
    $higitem1= $sortitem1[$nhig];
}

if($entid2 >= 0){
    @sortitem2= sort bynumber @item2;
    $meditem2= $sortitem2[$nmed];
    $lowitem2= $sortitem2[$nlow];
    $higitem2= $sortitem2[$nhig];
}

open(OUTFILE,">$statfile");
printf OUTFILE "%13f %13f %13f %13f %13f %13f\n",$meditem1,$lowitem1,$higitem1,$meditem2,$lowitem2,$higitem2;
printf "%13f %13f %13f %13f %13f %13f\n",$meditem1,$lowitem1,$higitem1,$meditem2,$lowitem2,$higitem2;
close(OUTFILE);
printf "did $mcmcfile with $npt points\n";
